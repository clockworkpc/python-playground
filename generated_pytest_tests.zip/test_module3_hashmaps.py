import pytest
from code.module3_hashmaps import Module3

def test_get_value():
    assert Module3.get_value({'a': 1}, 'a') == 1

def test_has_key():
    assert Module3.has_key({'a': 1}, 'a') == True

def test_invert_dict():
    assert Module3.invert_dict({'a': 1}) == {1: 'a'}

def test_merge_dicts():
    assert Module3.merge_dicts({'a': 1}, {'b': 2}) == {'a': 1, 'b': 2}

def test_dict_keys():
    assert Module3.dict_keys({'a': 1}) == ['a']
